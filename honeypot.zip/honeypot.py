import socket
from datetime import datetime

HOST = '0.0.0.0'  # Listen on all interfaces
PORT = 2222       # Fake SSH port

def log_event(ip, username, password):
    with open("honeypot_log.txt", "a") as log:
        log.write(f"{datetime.now()} - IP: {ip} - Username: {username} - Password: {password}\n")

def run_honeypot():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((HOST, PORT))
        s.listen(5)
        print(f"[*] Honeypot listening on port {PORT}...")

        while True:
            conn, addr = s.accept()
            ip = addr[0]
            print(f"[+] Connection from {ip}")
            conn.sendall(b"Username: ")
            username = conn.recv(1024).strip().decode()
            conn.sendall(b"Password: ")
            password = conn.recv(1024).strip().decode()

            print(f"[!] Fake login attempt - {username}:{password}")
            log_event(ip, username, password)
            conn.sendall(b"Access denied.\n")
            conn.close()

if __name__ == "__main__":
    run_honeypot()
